module.exports = {
    'title': 'Excel Assistant',
    'open': 'open',
    'srcDir': 'excel dir: ',
    'destDir': 'output dir: ',
    'outputExt': 'output format: ',
    'rememberSettings': 'remember settings',
    'build': 'build',
    'success': 'success',
    'close': 'close',
    'dirError': 'excelDir or outputDir is null!',
    'closeExcelRetry': 'please close excel file and retry build',
};