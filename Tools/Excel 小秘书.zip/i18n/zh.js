module.exports = {
    'title': 'Excel 小助手',
    'open': '打开',
    'srcDir': 'excel目录: ',
    'destDir': '输出目录: ',
    'outputExt': '输出格式: ',
    'rememberSettings': '记住设置',
    'build': '生成',
    'success': '成功',
    'close': '关闭',
    'dirError': 'Excel 目录或输出目录不正确！',
    'closeExcelRetry': '请关闭excel文件重试',
};